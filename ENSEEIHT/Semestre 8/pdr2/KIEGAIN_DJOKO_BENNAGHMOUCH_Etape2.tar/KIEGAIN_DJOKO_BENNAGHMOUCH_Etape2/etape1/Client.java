import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Observable;
import java.rmi.registry.*;
import java.net.*;

public class Client extends UnicastRemoteObject  implements Client_itf {
	//server
	private static Server_itf serveur;
	//client
	private static Client_itf client;
	// objects with an id
	private static Map<Integer, SharedObject> annuaire;
	
	private static ObjetRappel objetRappel;
	
	private static Map<Integer, Boolean> istracking;

	public Client() throws RemoteException {
		super();
		//self = this;// why?
	}


///////////////////////////////////////////////////
//         Interface to be used by applications
///////////////////////////////////////////////////

	// initialization of the client layer
	public static void init() {
		annuaire = new HashMap<Integer, SharedObject> ();
		istracking = new HashMap<Integer, Boolean> ();
	
		try {
			client = new Client();
			objetRappel = new ObjetRappel(client);
			Registry r = LocateRegistry.getRegistry(1099);
			r.bind(client.toString(), objetRappel);
			serveur = (Server_itf) r.lookup("Serveur"); // a voir
		} catch ( Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// lookup in the name server
	public static SharedObject lookup(String name) {
		SharedObject new_obj = null;
		try {
			int obj_id = serveur.lookup(name);
			if (obj_id != -1){
				if (annuaire.get(obj_id) != null) {
					new_obj = annuaire.get(obj_id);
				}else {
					new_obj = new SharedObject(obj_id, new Object());
					annuaire.put(obj_id, new_obj);
					istracking.put(obj_id, false);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new_obj;
	}		
	
	// binding in the name server
	public static void register(String name, SharedObject so) {
		try {
			serveur.register(name, so.getId());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	// creation of a shared object
	public static SharedObject create(Object o) {
		try{
			int id = serveur.create(o);
			SharedObject so = new SharedObject(id, o);
			annuaire.put(id, so);
			istracking.put(id, false);
			return so;
		} catch (RemoteException e){
			System.exit(0);
		}
		return null;
	}

	public static void ping(SharedObject so) {
		try {
			serveur.ping(so.getId());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	public static void pong(SharedObject so) {
		try {
			serveur.pong(so);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
	
	public static void follow(SharedObject so) throws RemoteException {
		serveur.follow(so.getId(),client.toString());
		System.out.println(" s'est abonné à l'objet"+so.getId());
		
	}

	public static void unfollow(SharedObject so) throws RemoteException {
		serveur.unfollow(so.getId(),client.toString());
		System.out.println(" s'est désabonné à l'objet"+so.getId());
	}
	@SuppressWarnings("deprecation")
	@Override
	public void notification() {
		try {
			objetRappel.notifieFollower();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		System.out.println("l'objet auquelle vous êtes abonnés va être modifié");
	}
	
	@SuppressWarnings("deprecation")
	public static ObjetRappel getObservable() {
		return objetRappel;
	}
	
	public static void track(SharedObject so) throws RemoteException {
		serveur.track(so.getId(),client.toString());
		System.out.println(" is tracking the object"+so.getId());
		istracking.put(so.getId(), true);
		
	}

	public static void untrack(SharedObject so) throws RemoteException {
		serveur.untrack(so.getId(),client.toString());
		System.out.println(" is tracking the object"+so.getId());
		istracking.put(so.getId(), false);

	}
	
/////////////////////////////////////////////////////////////
//    Interface to be used by the consistency protocol
////////////////////////////////////////////////////////////

	// request a read lock from the server
	public static Object lock_read(int id) {
		try {
			if (istracking.get(id)) {
				return annuaire.get(id).obj;
			} else {
				return serveur.lock_read(id, client);
			}
		} 
		catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// request a write lock from the server
	public static Object lock_write (int id) {
		try {
				return serveur.lock_write(id, client);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// receive a lock reduction request from the server
	public Object reduce_lock(int id) throws java.rmi.RemoteException {
		return annuaire.get(id).reduce_lock();
	}


	// receive a reader invalidation request from the server
	public void invalidate_reader(int id) throws java.rmi.RemoteException {
		annuaire.get(id).invalidate_reader();
	}


	// receive a writer invalidation request from the server
	public Object invalidate_writer(int id) throws java.rmi.RemoteException {
		return annuaire.get(id).invalidate_writer();
	}


	@Override
	public void updateObject(int id,Object updatedObj) throws java.rmi.RemoteException{
		annuaire.get(id).setObject(updatedObj);
	}

}
