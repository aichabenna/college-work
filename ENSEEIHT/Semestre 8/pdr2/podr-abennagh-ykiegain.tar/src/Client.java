import java.rmi.*; 
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.rmi.registry.*;

public class Client extends UnicastRemoteObject  implements Client_itf {
	
	private static final long serialVersionUID = 1L;
	
	private static Server_itf serveur;
	private static Client_itf client;
	
	public static Moniteur monitor;

	public static String siteName;
	
	private static Map<Integer, SharedObject> id_to_sharedObject;
	private static Map<String, Integer> name_to_id;
	private static Map<Integer, Integer> id_to_version;
	
	
	private static Set<Client_itf> clients;
		
	public Client() throws RemoteException {
		super();
	}

	// init 
	public static void init(String name) {
		siteName = name;
		
		id_to_sharedObject = new HashMap<Integer, SharedObject> ();
		name_to_id = new HashMap<String, Integer>();
		id_to_version = new HashMap<Integer, Integer>();
		
		try {
			client = new Client();
			
			Registry r = LocateRegistry.getRegistry(1099);
						
			serveur = (Server_itf) r.lookup("Serveur");
			
			clients = serveur.addClient(client);

		} catch ( Exception e) {
			e.printStackTrace();
		}
	}
	
	// lookup in the name server
	public static SharedObject lookup(String name) {
		SharedObject new_obj = null;
		try {
			int obj_id = serveur.lookup(name);
			if (obj_id != -1){
				if (id_to_sharedObject.get(obj_id) != null) {
					new_obj = id_to_sharedObject.get(obj_id);
				}else {
					new_obj = new SharedObject(obj_id, new Object());
					id_to_sharedObject.put(obj_id, new_obj);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new_obj;
	}		
	
	public void initSO(int idObj, Object valeur) throws java.rmi.RemoteException{
		SharedObject so = new SharedObject(idObj, valeur);
		id_to_sharedObject.put(idObj,so);
		id_to_version.put(idObj, 0);
	}
	
	public static SharedObject publish(String name, Object val, boolean b) {
		// TODO Auto-generated method stub
		try {
			
			int id = serveur.publish(name, val, b);
			SharedObject so = new SharedObject(id, val);
			//id_to_sharedObject.put(id, so);
			//Client.initSO(id, val);
			
			return so;
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	// instrumentation : fournit un nom pour le site, fixé à l'initialisation
	public String getSite() throws java.rmi.RemoteException{
		return siteName;
	}
	
	public static String getIdSite() {
		return siteName;
	}
	
	public Object getObj(String name) throws java.rmi.RemoteException{
		int id = name_to_id.get(name);
		SharedObject_itf so = id_to_sharedObject.get(id);
		return so.getObject();
	}
	
	public int getVersion(String name) throws java.rmi.RemoteException{
		int id = name_to_id.get(name);
		SharedObject_itf so = id_to_sharedObject.get(id);
		return so.getVersion();
	}

	public static Moniteur getMonitor() {
		return monitor;
	}

	public void setMonitor(Moniteur monitor) throws java.rmi.RemoteException{
		Client.monitor = monitor;
	}
	
	public void reportValue(int idObj, ReadCallBack rcb) throws java.rmi.RemoteException{
		//int id = name_to_id.get(siteName);
		/*SharedObject so = id_to_sharedObject.get(idObj);
		so.reportValue(rcb);*/
		if (id_to_sharedObject.get(idObj) != null){
			id_to_sharedObject.get(idObj).reportValue(rcb);
		}
	}
	
	public void update(int idObj, int version, Object valeur, WriteCallBack wcb) throws java.rmi.RemoteException {
		SharedObject so = id_to_sharedObject.get(idObj);
		so.update(version, valeur, wcb);
		id_to_version.put(idObj, version);
	}
	
	public static void write(int id, Object o) throws RemoteException {
		// TODO Auto-generated method stub
		int version = serveur.write(id, o);
		id_to_version.put(id, version);
	}
	
	public static Object read(int id) throws RemoteException {
				
		//Bloc de code pour la lecture des registres en mode régulier
		//return id_to_sharedObject.get(id).getObject();

		//Bloc de Code pour la lecture des registres en mode atomiques
		ReadCallBack rcb = new ReadCallbackImpl(serveur.lastVersion(id));
		for(Client_itf c : clients){
		    new Thread(()->{
				try {
				    c.reportValue(id, rcb);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
				System.out.println(c.toString() + " updated.");
			}).start();;
		}
		rcb.waitForResponse();
		return rcb.getObj();
	}
}
