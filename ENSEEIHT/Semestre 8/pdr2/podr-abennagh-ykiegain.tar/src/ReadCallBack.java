import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ReadCallBack extends Remote{

	public int getId() throws RemoteException;

	public Object getObj() throws RemoteException;

	public int getVersion() throws RemoteException;
	
	public void setId(int id) throws RemoteException;

	public void setObj(Object obj) throws RemoteException;

	public void setVersion(int version) throws RemoteException;

    public void waitForResponse() throws RemoteException;
    
	public void response(int version, Object valeur) throws RemoteException;
}
