import java.rmi.RemoteException;

public interface SharedObject_itf {
	public void update(int v, Object valeur, WriteCallBack wcb);
    public void reportValue(ReadCallBack rcb) ;
    public void write(Object o) ;
    //public synchronized Object read();
	public int getVersion() ;
	public void setVersion(int version) ;
	
	public void setObject(Object o);
	public Object getObject();

	
}