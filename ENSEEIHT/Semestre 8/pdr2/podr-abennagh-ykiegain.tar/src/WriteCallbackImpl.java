import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.CountDownLatch;

public class WriteCallbackImpl extends UnicastRemoteObject implements WriteCallBack{
	private int id;
	private Object obj;
	private int version;
	private final CountDownLatch latch;

    public WriteCallbackImpl() throws RemoteException{
        this.latch = new CountDownLatch(1);
    }
	
	public int getId() {
		return id;
	}
	public void setId(int id) throws RemoteException{
		this.id = id;
	}
	public Object getObj() {
		return obj;
	}
	public void setObj(Object obj) throws RemoteException{
		this.obj = obj;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) throws RemoteException{
		this.version = version;
	}
	
	@Override
    public synchronized void response() throws RemoteException {
        latch.countDown();
    }
	
	public void waitForResponse() throws RemoteException {
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
