
public class ServerObject{
	
	private int id;
	private Object obj;
	private int version;
	
	public ServerObject (int id, Object initObj, int version) {
		this.id = id;
		this.obj =initObj;
		this.version = version;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}
