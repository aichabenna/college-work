import java.io.*; 
import java.rmi.RemoteException;

public class SharedObject implements Serializable, SharedObject_itf {
	
    private static final long serialVersionUID = 1L;
	
    private int version;
	private int id;
	public Object obj;
	

	public SharedObject (int initId, Object initObj) {
		this.id = initId;
		this.obj = initObj;
	}
	
	public void setVersion(int version) {
		this.version = version;
	}
	
	public int getVersion() {
		// TODO Auto-generated method stub
		return version;
	}
	
	public int getId() {
		return this.id;
	}
	
	public void setObject(Object o) {
		obj = o;
	}
	
	public Object getObject() {
		return obj;
	}
	
	public void update(int v, Object valeur, WriteCallBack wcb) {
        try {
            Client.monitor.feuVert(Client.getIdSite(),4); // ** Instrumentation
         	// ** attente quadruplée pour les ack, pour exhiber l'inversion de valeurs
         	// getIdSite identique à getSite, mais non Remote
         	
         	// suite de la méthode update... 
            if(v >this.version) {
	            version = v;
	            obj = valeur;
	            
	            wcb.setId(id);
	    		wcb.setObj(valeur);
	    		wcb.setVersion(v);
            }
            wcb.response();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
         	
    }

    public void reportValue(ReadCallBack rcb) {
        try {
            Client.monitor.feuVert(Client.getIdSite(),1); // ** Instrumentation
            
         	// suite de la méthode reportValue... 
            rcb.setId(id);
            rcb.setObj(obj);
            rcb.setVersion(version);
            rcb.response(version,obj);
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    // invoked by the user program on the client node
    // passage par Client pour que les écritures soient demandées en séquence sur le site
    public void write(Object o) {
        try {
            Client.monitor.signaler("DE",Client.getIdSite(),id); // ** Instrumentation
            Client.write(id,o);
            Client.monitor.signaler("TE",Client.getIdSite(),id); // ** Instrumentation
        } catch (RemoteException rex) {
            rex.printStackTrace();
        }
    }

    // pour simplifier (éviter les ReadCallBack actifs simultanés)
    // on évite les lectures concurrentes sur une même copie
    public synchronized Object read() {
        // déclarations méthode read....

        try {
            Client.monitor.signaler("DL",Client.getIdSite(),id); // ** Instrumentation
            
            //corps de la méthode read...
            obj = Client.read(id);
            
            
            Client.monitor.signaler("TL",Client.getIdSite(),id); // ** Instrumentation
            return obj;
        } catch (RemoteException rex) {
            rex.printStackTrace();
            return null;
        }
    }
}
