import java.rmi.Remote;
import java.rmi.RemoteException;

public interface WriteCallBack extends Remote{

	void setId(int id) throws RemoteException;

	void setObj(Object valeur) throws RemoteException;

	void setVersion(int v) throws RemoteException;

	public void response() throws RemoteException;

    public void waitForResponse() throws RemoteException;
}
