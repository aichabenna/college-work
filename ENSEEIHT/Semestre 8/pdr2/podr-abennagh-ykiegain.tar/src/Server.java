import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

public class Server extends UnicastRemoteObject implements Server_itf {
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private Registry registry;
	
	private Map<String, Integer> name_to_id;
	private Map<Integer, ServerObject> id_to_serverObject;
	private Map<Integer, Integer> id_to_version;

	private Set<Client_itf> clients;

	private Moniteur monitor;
	private CountDownLatch start;
	private static HashMap<String, CountDownLatch> initControler;
	int NBCLIENTS = 3;
	
	protected Server () throws RemoteException {
		super();
		name_to_id = new HashMap<String, Integer>();
		id_to_serverObject = new HashMap<Integer, ServerObject>();
		id_to_version = new HashMap<Integer, Integer>();

		clients = new HashSet<Client_itf>();
		id = 0;
		registry = LocateRegistry.getRegistry(1099);
		start = new CountDownLatch(NBCLIENTS);
		initControler = new HashMap<>();
		
	}

	@Override
	public int lookup(String name) throws RemoteException {
		Integer id =  name_to_id.get(name);
		
		if (id == null){
			name_to_id.put(name, -1); //pour differencier avec le cas où il n'a jamais été visité et id = null
            initControler.put(name, new CountDownLatch(1));
            return -1;
		} else if(id == -1) {
			try {
				initControler.get(name).await();
				id = name_to_id.get(name);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return id;
	}


	@Override
	public synchronized int publish(String name, Object o, boolean reset) throws RemoteException {
		// TODO Auto-generated method stub
		ServerObject so = new ServerObject(id, o, 0);
		id_to_serverObject.put(id, so);
		name_to_id.put(name, id);
		id_to_version.put(id, 0);
		
		for(Client_itf client : clients) {
			client.initSO(id, o);
		}
		initControler.get(name).countDown();
		id++;
		return id-1;
	}

	// architecture nécessaire au démarrage : serveur dans registry, 
	// tous sites enregistrés auprès du serveur
	// enregistre un site et récupère la liste complète (cardinal connu au lancement)
	@Override
	public Set<Client_itf> addClient(Client_itf client) throws RemoteException {
		clients.add(client);
		start.countDown();
		try {
			start.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clients;
	}
	
	@Override
	public String[] list() throws RemoteException {
		Set<String> keySet = name_to_id.keySet();
        String[] keysArray = keySet.toArray(new String[keySet.size()]);
        return keysArray;
	}

	@Override
	public Set<Client_itf> setMonitor(Moniteur m) throws RemoteException {
		// TODO Auto-generated method stub
		this.monitor = m;
		return clients;
	}

	@Override
	public Moniteur getMonitor() throws RemoteException {
		// TODO Auto-generated method stub
		return Client.monitor;
	}

	@Override
	public synchronized int write(int idObjet, Object valeur) throws RemoteException {
		// TODO Auto-generated method stub
		ServerObject so = id_to_serverObject.get(idObjet);
		so.setObj(valeur);
		int version = so.getVersion()+1;
		so.setVersion(version);
		
		WriteCallBack wcb = new WriteCallbackImpl();
		for(Client_itf c : clients) {
			new Thread(()->{
				try {
					c.update(idObjet, version, valeur, wcb);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
				System.out.println(c.toString() + " updated.");
			}).start();;
				
		}
		wcb.waitForResponse();
		id_to_version.put(idObjet, version);
		return version;
	}

	public int lastVersion(int idObj) throws RemoteException {
        return id_to_version.get(idObj);
    }
	
	public static void main(String args[]) {
		try {
			Registry registry = LocateRegistry.createRegistry(1099);
			// Create an instance of the server object
			Server sv = new Server();
			// Register the object with the naming service
			//Naming.rebind("//localhost:1099/Serveur", sv);
			registry.bind("Serveur", sv);
		}catch(Exception exc) {
			exc.printStackTrace();
		}
	}
}
