import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.CountDownLatch;

public class ReadCallbackImpl extends UnicastRemoteObject implements ReadCallBack{
	private int id;
	private Object obj;
	private int version;
	private final CountDownLatch latch;
    private boolean done;
    private int lastVersion;
	
	public ReadCallbackImpl(int version) throws RemoteException{
		this.latch = new CountDownLatch(1);
        this.done = false;
        this.lastVersion = version;
	}
	
	public int getId() throws RemoteException{
		return id;
	}
	public void setId(int id){
		this.id = id;
	}
	public Object getObj() throws RemoteException{
		return obj;
	}
	public void setObj(Object obj) {
		this.obj = obj;
	}
	public int getVersion() throws RemoteException{
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	
	//réponse(version : entier, valeur : Object) : permet au client de transmettre sa version
	//courante de l’objet partagé, en réponse à l’enquête.
	public void response(int version, Object valeur) throws RemoteException{
        if (version>=this.lastVersion && !done){
    		this.version = version;
    		this.obj = valeur;
            latch.countDown();
            done = true;
        }
	}

	@Override
	public void waitForResponse() throws RemoteException {
		try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	}
}
