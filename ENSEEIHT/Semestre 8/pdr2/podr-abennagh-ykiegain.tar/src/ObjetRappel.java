import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Observable;

public class ObjetRappel extends UnicastRemoteObject implements ObjetRappel_itf{
	private ObjetObservable obs;
	private Client_itf client;
	protected ObjetRappel(Client_itf initClient) throws RemoteException {
		super();
		obs = new ObjetObservable();
		client = initClient;
	}

	public void notifieFollower() throws RemoteException{
		obs.notifieObjetObservable();
	}
	
	public void notifieTracker(int i,Object obj) throws RemoteException{
		obs.notifieObjetObservable();
	}
	
	public ObjetObservable getObjetObservable() {
		return obs;
	}
}

interface ObjetRappel_itf extends Remote {
    void notifieFollower() throws RemoteException;
    void notifieTracker(int id, Object obj) throws RemoteException;
}

class ObjetObservable extends Observable{
	public void notifieObjetObservable() {
		setChanged();
		notifyObservers();
	}
}
