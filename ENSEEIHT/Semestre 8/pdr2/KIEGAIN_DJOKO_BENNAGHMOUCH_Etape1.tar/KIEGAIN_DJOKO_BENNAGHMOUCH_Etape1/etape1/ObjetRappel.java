import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Observable;

public class ObjetRappel extends UnicastRemoteObject implements ObjetRappel_itf{
	private ObjetObservable obs;
	protected ObjetRappel() throws RemoteException {
		super();
		obs = new ObjetObservable();
		// TODO Auto-generated constructor stub
	}

	public void notifie() throws RemoteException{
		obs.notifieObjetObservable();
	}
	
	public ObjetObservable getObjetObservable() {
		return obs;
	}
}

interface ObjetRappel_itf extends Remote {
    void notifie() throws RemoteException;
}

class ObjetObservable extends Observable{
	public void notifieObjetObservable() {
		setChanged();
		notifyObservers();
	}
}
