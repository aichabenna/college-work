import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;

import javax.sound.midi.VoiceStatus;
import javax.swing.text.AbstractDocument.LeafElement;

public class ServerObject{
	enum states {NL,RL,WL};
	private int id;
	private states lockType;
	private Client_itf writer; 
	private List<Client_itf> readers;
	private List<ObjetRappel_itf> followers;
	private Object obj;
	
	public ServerObject (int id, Object initObj) {
		this.id = id;
		this.obj =initObj;
		this.lockType = states.NL;
		this.readers = new ArrayList<Client_itf>();
		this.followers = new ArrayList<ObjetRappel_itf>();
	}

	public Object lock_read(Client_itf c) throws RemoteException{
		if (this.lockType == states.NL ){
			lockType = states.RL;
		} 
		else if(this.lockType == states.WL){
			this.obj = writer.reduce_lock(id);
			readers.add(writer);
			lockType =states.RL;
		}
		readers.add(c);
		return this.obj;
	}

	public Object lock_write(Client_itf c) throws RemoteException{
		if (this.lockType == states.NL){
			lockType = states.WL;
		}else if(this.lockType == states.WL){
			this.obj = writer.invalidate_writer(this.id);
		}else if(this.lockType == states.RL) {
			for(Client_itf r : readers){
				r.invalidate_reader(id);
			}
			lockType = states.WL;
		}
		writer = c;
		return this.obj;
	}

	public void follow(ObjetRappel_itf objR) {
		if (!followers.contains(objR)) {
			followers.add(objR);
		} else {
			System.out.println("le client est déja abonnée");
		}
	}

	public void unfollow(ObjetRappel_itf objR) {
		if (followers.contains(objR)) {
			followers.remove(objR);
		} else {
			System.out.println("le client n'est pas abonnée");
		}
	}

	public synchronized void ping() {
		for (ObjetRappel_itf f : followers) {
			try {
				f.notifie();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
