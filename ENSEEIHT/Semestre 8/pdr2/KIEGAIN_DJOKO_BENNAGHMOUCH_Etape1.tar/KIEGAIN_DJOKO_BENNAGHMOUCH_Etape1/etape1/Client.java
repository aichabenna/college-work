import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Observable;
import java.rmi.registry.*;
import java.net.*;

public class Client extends UnicastRemoteObject  implements Client_itf {
	//server
	private static Server_itf serveur;
	//client
	private static Client_itf client;
	// objects with an id
	private static Map<Integer, SharedObject> annuaire;
	
	private static ObjetRappel objetRappel;

	public Client() throws RemoteException {
		super();
		//self = this;// why?
	}


///////////////////////////////////////////////////
//         Interface to be used by applications
///////////////////////////////////////////////////

	// initialization of the client layer
	public static void init() {
		annuaire = new HashMap<Integer, SharedObject> ();
		try {
			objetRappel = new ObjetRappel();
			client = new Client();
			Registry r = LocateRegistry.getRegistry(1099);
			r.bind(client.toString(), objetRappel);
			serveur = (Server_itf) r.lookup("Serveur"); // a voir
		} catch ( Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// lookup in the name server
	public static SharedObject lookup(String name) {
		try {
			int obj_id = serveur.lookup(name);
			if (obj_id == -1){
				return null;
			}
			SharedObject new_obj = new SharedObject(obj_id, annuaire.get(obj_id));
			annuaire.put(obj_id, new_obj);
			return new_obj;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}		
	
	// binding in the name server
	public static void register(String name, SharedObject so) {
		try {
			/*for (Integer i : annuaire.keySet()) {
				if (annuaire.get(i) == so) {
					
				}
			}*/
			serveur.register(name, so.getId());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// creation of a shared object
	public static SharedObject create(Object o) {
		try{
			int id = serveur.create(o);
			SharedObject so = new SharedObject(id, o);
			annuaire.put(id, so);
			return so;
		} catch (RemoteException e){
			System.exit(0);
		}
		return null;
	}

	public static void ping(SharedObject so) {
		try {
			serveur.ping(so.getId());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void follow(SharedObject so) throws RemoteException {
		serveur.follow(so.getId(),client.toString());
		System.out.println(" s'est abonné à l'objet"+so.getId());
		
	}

	public static void unfollow(SharedObject so) throws RemoteException {
		serveur.unfollow(so.getId(),client.toString());
		System.out.println(" s'est désabonné à l'objet"+so.getId());
	}
	@SuppressWarnings("deprecation")
	@Override
	public void notification() {
		try {
			objetRappel.notifie();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("l'objet auquelle vous êtes abonnés va être modifié");
	}
	
	@SuppressWarnings("deprecation")
	public static ObjetRappel getObservable() {
		return objetRappel;
	}
/////////////////////////////////////////////////////////////
//    Interface to be used by the consistency protocol
////////////////////////////////////////////////////////////

	// request a read lock from the server
	public static Object lock_read(int id) {
		try {
			return serveur.lock_read(id, client);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// request a write lock from the server
	public static Object lock_write (int id) {
		try {
			return serveur.lock_write(id, client);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// receive a lock reduction request from the server
	public Object reduce_lock(int id) throws java.rmi.RemoteException {
		return annuaire.get(id).reduce_lock();
	}


	// receive a reader invalidation request from the server
	public void invalidate_reader(int id) throws java.rmi.RemoteException {
		annuaire.get(id).invalidate_reader();
	}


	// receive a writer invalidation request from the server
	public Object invalidate_writer(int id) throws java.rmi.RemoteException {
		return annuaire.get(id).invalidate_writer();

	}

}
