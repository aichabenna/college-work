import java.awt.*;
import java.awt.event.*;
import java.rmi.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;
import java.rmi.registry.*;


public class Irc2 extends Frame implements Observer{
	public TextArea		text;
	public TextField	data;
	SharedObject		sentence;
	static String		myName;

	public static void main(String argv[]) {
		
		if (argv.length != 1) {
			System.out.println("java Irc2 <name>");
			return;
		}
		myName = argv[0];
	
		// initialize the system
		Client.init();
		
		// look up the IRC object in the name server
		// if not found, create it, and register it in the name server
		SharedObject s = Client.lookup("IRC");
		if (s == null) {
			s = Client.create(new Sentence());
			Client.register("IRC", s);
		}
		// create the graphical part
		new Irc2(s);
	}

	@SuppressWarnings("deprecation")
	public Irc2(SharedObject s) {
		Client.getObservable().getObjetObservable().addObserver(this);
		setLayout(new FlowLayout());
	
		text=new TextArea(10,60);
		text.setEditable(false);
		text.setForeground(Color.red);
		add(text);
	
		data=new TextField(60);
		add(data);
	
		Button write_button = new Button("write");
		write_button.addActionListener(new writeListener2(this));
		add(write_button);
		Button read_button = new Button("read");
		read_button.addActionListener(new readListener2(this));
		add(read_button);

		/********************** FOLLOW - UNFOLLOW ********************/
		Button follow_button = new Button("follow");
		follow_button.addActionListener(new followListener2(this));
		add(follow_button);
		Button unfollow_button = new Button("unfollow");
		unfollow_button.addActionListener(new unfollowListener2(this));
		add(unfollow_button);
		/*************************************************************/
		
		setSize(600,300);
		text.setBackground(Color.black); 
		show();
		
		sentence = s;
	}

	@Override
	public void update(@SuppressWarnings("deprecation") Observable o, Object arg) {
		if (o == Client.getObservable().getObjetObservable()) {
            text.append("l'objet a été modifié\n");
        }
	}
}



class readListener2 implements ActionListener {
	Irc2 irc;
	public readListener2 (Irc2 i) {
		irc = i;
	}
	public void actionPerformed (ActionEvent e) {
		
		// lock the object in read mode
		irc.sentence.lock_read();
		
		// invoke the method
		String s = ((Sentence)(irc.sentence.obj)).read();
		
		// unlock the object
		irc.sentence.unlock();
		
		// display the read value
		irc.text.append(s+"\n");
	}
}

class writeListener2 implements ActionListener {
	Irc2 irc;
	public writeListener2 (Irc2 i) {
        	irc = i;
	}
	public void actionPerformed (ActionEvent e) {
		
		// get the value to be written from the buffer
        	String s = irc.data.getText();
        	
        	// lock the object in write mode
		irc.sentence.lock_write();
		
		// invoke the method
		((Sentence)(irc.sentence.obj)).write(Irc2.myName+" wrote "+s);
		irc.data.setText("");
		
		// unlock the object
		irc.sentence.unlock();
	}
}

class unfollowListener2 implements ActionListener {
	Irc2 irc;

	public unfollowListener2(Irc2 i) {
		irc = i;
	}

	public void actionPerformed(ActionEvent e) {

		// unfollow 
		try {
			Client.unfollow(irc.sentence);
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

class followListener2 implements ActionListener {
	Irc2 irc;

	public followListener2(Irc2 i) {
		irc = i;
	}

	public void actionPerformed(ActionEvent e) {

		// follow
		try {
			Client.follow(irc.sentence);
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
