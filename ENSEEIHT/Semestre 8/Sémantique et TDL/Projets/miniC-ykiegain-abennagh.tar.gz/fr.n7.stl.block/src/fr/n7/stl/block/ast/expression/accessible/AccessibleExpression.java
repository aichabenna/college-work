/**
 * 
 */
package fr.n7.stl.block.ast.expression.accessible;

import fr.n7.stl.block.ast.expression.Expression;

/**
 * Expression whose value can be read.
 * @author Marc Pantel
 *
 */
public interface AccessibleExpression extends Expression  {

}
