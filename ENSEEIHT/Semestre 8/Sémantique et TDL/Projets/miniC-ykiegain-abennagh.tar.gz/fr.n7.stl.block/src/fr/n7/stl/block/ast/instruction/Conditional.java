/**
 * 
 */
package fr.n7.stl.block.ast.instruction;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

import fr.n7.stl.block.ast.Block;
import fr.n7.stl.block.ast.SemanticsUndefinedException;
import fr.n7.stl.block.ast.expression.Expression;
import fr.n7.stl.block.ast.scope.Declaration;
import fr.n7.stl.block.ast.scope.HierarchicalScope;
import fr.n7.stl.block.ast.type.AtomicType;
import fr.n7.stl.block.ast.type.Type;
import fr.n7.stl.tam.ast.Fragment;
import fr.n7.stl.tam.ast.Register;
import fr.n7.stl.tam.ast.TAMFactory;
import fr.n7.stl.util.Logger;

/**
 * Implementation of the Abstract Syntax Tree node for a conditional instruction.
 * @author Marc Pantel
 *
 */
public class Conditional implements Instruction {

	protected Expression condition;
	protected Block thenBranch;
	protected Block elseBranch;

	public Conditional(Expression _condition, Block _then, Block _else) {
		this.condition = _condition;
		this.thenBranch = _then;
		this.elseBranch = _else;
	}

	public Conditional(Expression _condition, Block _then) {
		this.condition = _condition;
		this.thenBranch = _then;
		this.elseBranch = null;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "if (" + this.condition + " )" + this.thenBranch + ((this.elseBranch != null)?(" else " + this.elseBranch):"");
	}
	
	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.instruction.Instruction#collect(fr.n7.stl.block.ast.scope.Scope)
	 */
	@Override
	public boolean collectAndBackwardResolve(HierarchicalScope<Declaration> _scope) {
		boolean _condition = condition.collectAndBackwardResolve(_scope);
		boolean _thenBranch = thenBranch.collect(_scope);
		boolean _elseBranch = true;
		if (elseBranch != null) {
			_elseBranch = elseBranch.collect(_scope);
		}
		return  _condition &&  _thenBranch && _elseBranch;
	}
	
	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.instruction.Instruction#resolve(fr.n7.stl.block.ast.scope.Scope)
	 */
	@Override
	public boolean fullResolve(HierarchicalScope<Declaration> _scope) {
		boolean _condition = condition.fullResolve(_scope);
		boolean _thenBranch = thenBranch.resolve(_scope);
		boolean _elseBranch = true;
		if (elseBranch != null) {
			_elseBranch = elseBranch.resolve(_scope);
		}
		return _condition && _thenBranch && _elseBranch;
	}

	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Instruction#checkType()
	 */
	@Override
	public boolean checkType() {
		Type conditionType = condition.getType();
		boolean _condition = true;
		if (!(conditionType.compatibleWith(AtomicType.BooleanType))) {
			Logger.error("Wrong type");
			_condition = false;;
		}
		boolean _thenBranch = thenBranch.checkType();
		boolean _elseBranch = true;
		if (elseBranch != null) {
			_elseBranch = elseBranch.checkType();
		}
		return _condition && _thenBranch && _elseBranch;
	}

	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Instruction#allocateMemory(fr.n7.stl.tam.ast.Register, int)
	 */
	@Override
	public int allocateMemory(Register _register, int _offset) {
		thenBranch.allocateMemory(_register, _offset);
		if (elseBranch != null) {
			elseBranch.allocateMemory(_register, _offset);
		}
		return _offset; // not sure
	}

	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Instruction#getCode(fr.n7.stl.tam.ast.TAMFactory)
	 */
	@Override
	public Fragment getCode(TAMFactory _factory) {
		int num_blocif =_factory.createLabelNumber();
		Fragment _result = _factory.createFragment();
		// pas d'étiquette then
		_result.append(condition.getCode(_factory));
		
		if (elseBranch != null) {
			_result.add(_factory.createJumpIf("endif" + num_blocif, 0));
			_result.append(thenBranch.getCode(_factory));

		}else {
			_result.add(_factory.createJump("else" + num_blocif));
			_result.append(thenBranch.getCode(_factory));	
			_result.add(_factory.createJump("endif" + num_blocif));
			_result.addSuffix("else" + num_blocif);
			_result.append(elseBranch.getCode(_factory));

		}
		_result.addSuffix("endif"+num_blocif);
		return _result;
	}

}
