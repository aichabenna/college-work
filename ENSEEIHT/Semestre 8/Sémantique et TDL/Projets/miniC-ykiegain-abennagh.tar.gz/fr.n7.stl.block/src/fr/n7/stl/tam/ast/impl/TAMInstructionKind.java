/**
 * 
 */
package fr.n7.stl.tam.ast.impl;

/**
 * List the Various TAM instructions.
 * @author Marc Pantel
 *
 */
enum TAMInstructionKind {
	LOAD, LOADL, LOADI, LOADA,
	STORE, STOREI,
	PUSH, POP,
	JUMP,
	JUMPIF,
	CALL, CALLI,
	RETURN,
	SUBR,
	HALT;
}
