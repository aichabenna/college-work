package fr.n7.stl.block;

import java.io.File;

class Driver {

	public static void main(String[] args) throws Exception {
		Parser parser = null;
		File dossier = new File("Test");
	    File[] fichiers = dossier.listFiles();
	    for (File fichier : fichiers) {
	    	if (fichier.getName().startsWith("KO")) {
				continue;
			}
        	parser = new Parser( "Test/"+fichier.getName() );
			parser.parse();
		    System.out.println("--------------------------------------------------------------------------------------------------");
		    System.out.println("");
	    }
	    
	    //Test getCode
	    /*
	    parser = new Parser( "Test/test01.txt" );
		parser.parse();
	    System.out.println("--------------------------------------------------------------------------------------------------");
	    System.out.println("");
	    */
	}
	
}