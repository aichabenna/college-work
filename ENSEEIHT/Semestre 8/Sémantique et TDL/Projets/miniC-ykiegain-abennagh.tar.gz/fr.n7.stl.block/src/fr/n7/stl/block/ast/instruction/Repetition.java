/**
 * 
 */
package fr.n7.stl.block.ast.instruction;

import fr.n7.stl.block.ast.Block;
import fr.n7.stl.block.ast.SemanticsUndefinedException;
import fr.n7.stl.block.ast.expression.Expression;
import fr.n7.stl.block.ast.scope.Declaration;
import fr.n7.stl.block.ast.scope.HierarchicalScope;
import fr.n7.stl.block.ast.scope.Scope;
import fr.n7.stl.block.ast.type.AtomicType;
import fr.n7.stl.block.ast.type.Type;
import fr.n7.stl.tam.ast.Fragment;
import fr.n7.stl.tam.ast.Register;
import fr.n7.stl.tam.ast.TAMFactory;
import fr.n7.stl.util.Logger;

/**
 * Implementation of the Abstract Syntax Tree node for a repetition instruction.
 * @author Marc Pantel
 *
 */
public class Repetition implements Instruction {

	protected Expression condition;
	protected Block body;

	public Repetition(Expression _condition, Block _body) {
		this.condition = _condition;
		this.body = _body;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "while (" + this.condition + ") " + this.body;
	}
	
	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.instruction.Instruction#collect(fr.n7.stl.block.ast.scope.Scope)
	 */
	@Override
	public boolean collectAndBackwardResolve(HierarchicalScope<Declaration> _scope) {
		boolean _condition = condition.collectAndBackwardResolve(_scope);
		boolean _body = body.collect(_scope);
		return  _condition &&  _body;
	}
	
	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.instruction.Instruction#resolve(fr.n7.stl.block.ast.scope.Scope)
	 */
	@Override
	public boolean fullResolve(HierarchicalScope<Declaration> _scope) {
		boolean _condition = condition.fullResolve(_scope);
		boolean _body = body.resolve(_scope);
		return  _condition &&  _body;	}

	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Instruction#checkType()
	 */
	@Override
	public boolean checkType() {
		Type conditionType = condition.getType();
		boolean _condition = true;
		if (!(conditionType.compatibleWith(AtomicType.BooleanType))) {
			Logger.error("Wrong type");
			_condition = false;;
		}
		boolean _body = body.checkType();
		return _condition && _body;
	}


	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Instruction#allocateMemory(fr.n7.stl.tam.ast.Register, int)
	 */
	@Override
	public int allocateMemory(Register _register, int _offset) {
		body.allocateMemory(_register, _offset);
		return _offset;
	}

	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Instruction#getCode(fr.n7.stl.tam.ast.TAMFactory)
	 */
	@Override
	public Fragment getCode(TAMFactory _factory) {
		int num_blocrepetition =_factory.createLabelNumber();
		Fragment _result = _factory.createFragment();
		
		_result.append(condition.getCode(_factory));
		_result.addSuffix("cond" + num_blocrepetition);
		
		_result.add(_factory.createJumpIf("body" + num_blocrepetition, 0));
		_result.add(_factory.createJump("end" + num_blocrepetition));
		
		Fragment body_result = body.getCode(_factory);
		body_result.addPrefix("body" + num_blocrepetition);
		body_result.addSuffix("end" + num_blocrepetition);
		body_result.add(_factory.createJump("cond" + num_blocrepetition));
		_result.append(body_result);
		return _result;
	}

}
