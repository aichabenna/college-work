public class Main {

	public static void main(String args[]) {
		int i = 10;
        while (i >= 0) {
            if ( i > 5) {
                print i;
            } else {
                print -i;
            }
            i = i - 1;
        }

	}
}