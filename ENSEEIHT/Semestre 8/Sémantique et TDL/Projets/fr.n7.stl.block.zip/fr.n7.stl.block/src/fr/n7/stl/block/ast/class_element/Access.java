package fr.n7.stl.block.ast.class_element;

public enum Access {
	Private,
	Protected,
	Public;
	
	public String toString() {
		switch(this) {
		case Private:
			return "private";
		case Protected:
			return "protected";
		case Public:
			return "public";
		default:
			throw new IllegalArgumentException("Cas jamais déclenché");
		}
	}
}
