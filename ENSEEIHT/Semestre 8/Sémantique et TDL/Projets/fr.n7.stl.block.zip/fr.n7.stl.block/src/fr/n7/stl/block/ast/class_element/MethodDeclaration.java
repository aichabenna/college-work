package fr.n7.stl.block.ast.class_element;

import java.util.List;

import fr.n7.stl.block.ast.Block;
import fr.n7.stl.block.ast.SemanticsUndefinedException;
import fr.n7.stl.block.ast.instruction.declaration.ParameterDeclaration;
import fr.n7.stl.block.ast.scope.Declaration;
import fr.n7.stl.block.ast.scope.HierarchicalScope;
import fr.n7.stl.block.ast.scope.SymbolTable;
import fr.n7.stl.block.ast.type.AtomicType;
import fr.n7.stl.block.ast.type.Type;
import fr.n7.stl.tam.ast.Fragment;
import fr.n7.stl.tam.ast.Register;
import fr.n7.stl.tam.ast.TAMFactory;
import fr.n7.stl.util.Logger;

public class MethodDeclaration implements ClassElement, Declaration {

    protected Access access;
    protected EtatElement etat;
    protected Signature sig;
    protected Block corps;
    protected SymbolTable table_param;
    protected int off;

    public MethodDeclaration(Access _access, EtatElement _etat, Signature _sig, Block _corps) {
        access = _access;
        etat = _etat;
        sig = _sig;
        corps = _corps;
    }

    public String toString() {
        return this.access.toString() + " " + this.etat.toString() + " " + this.sig.toString() + " "
                + corps;
    }

    public Access getAccess() {
        return this.access;
    }

    public Signature getSignature() {
        return this.sig;
    }

    @Override
    public String getName() {
        return this.sig.getName();
    }

    @Override
    public Type getType() {
        return this.sig.getType();
    }

    @Override
    public boolean collectAndBackwardResolve(HierarchicalScope<Declaration> _scope) {
        String name = sig.id.getLeft();
        String old_name = sig.id.getLeft();
        if (this.sig.param != null) {
            for (ParameterDeclaration p : this.sig.param) {
                name += p.getType().toString();
            }
        }
        sig.id.setLeft(name);
        if (((HierarchicalScope<Declaration>) _scope).accepts(this)) {
            _scope.register(this);
            SymbolTable params_loc = new SymbolTable(_scope);
            boolean res = true;
            List<ParameterDeclaration> param_sig = sig.getParameters();
            if (param_sig != null) {
                for (ParameterDeclaration d : param_sig) {
                    params_loc.register(d);
                }
            }
            table_param = params_loc;
            res = this.corps.collect(params_loc);
            return res;
        } else {
            System.out.println("Méthode déjà définie : " + old_name);
            return false;
        }
    }

    @Override
    public boolean fullResolve(HierarchicalScope<Declaration> _scope) {
        return this.corps.resolve(table_param);
    }

    @Override
    public boolean checkType() {
        boolean res = true;
        if (sig.param != null) {
            for(ParameterDeclaration par : sig.param) {
                if (par.getType().equalsTo(AtomicType.ErrorType)) {
                    System.out.println(par.toString() + " is not compatible with parameters type.");
                    res = false;
                }
            }
        }
		res = res && corps.checkType();
        return res;
    }

    @Override
    public int allocateMemory(Register _register, int _offset) {
        off = 0;
		for (ParameterDeclaration p : sig.getParameters()) {
			off += p.getType().length();
		}
		this.corps.allocateMemory(Register.LB, off);
		return 0;
    }

    @Override
    public Fragment getCode(TAMFactory _factory) {
        Fragment res = _factory.createFragment();
        res.append(corps.getCode(_factory));
		res.addPrefix("debut:" + sig.getName());
        if (sig.getType() == AtomicType.VoidType){
			res.add(_factory.createReturn(0, this.off));
		}
		res.addSuffix("fin:" + sig.getName());
        return res;
    }

}
