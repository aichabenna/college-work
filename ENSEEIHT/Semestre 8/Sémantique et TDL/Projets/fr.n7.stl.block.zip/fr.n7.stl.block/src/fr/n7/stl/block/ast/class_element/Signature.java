package fr.n7.stl.block.ast.class_element;

import java.util.Iterator;
import java.util.List;

import fr.n7.stl.block.ast.instruction.declaration.ParameterDeclaration;
import fr.n7.stl.block.ast.type.PartialType;
import fr.n7.stl.block.ast.type.Type;
import fr.n7.stl.util.Pair;

public class Signature {

    protected Type type;
    protected List<ParameterDeclaration> param;
    protected Pair<String, PartialType> id;
    public Signature(Type _type, Pair<String, PartialType> _id, List<ParameterDeclaration> _param) {
        this.type = _type;
        this.id = _id;
        this.param = _param;
    }

    public String toString() {
        String _result = type.toString() + " " + this.id.getLeft() + "(";
        if (param != null) {
            Iterator<ParameterDeclaration> _iter = this.param.iterator();
            if (_iter.hasNext()) {
                _result += _iter.next();
                while (_iter.hasNext()) {
                    _result += " ," + _iter.next();
                }
            }
        }
        return _result + ")";
    }

    public Type getType() {
        return this.type;
    }

    public String getName() {
        return this.id.getLeft();
    }

    public List<ParameterDeclaration> getParameters() {
        return this.param;
    }

}
