package fr.n7.stl.block.ast.class_element;

import fr.n7.stl.block.ast.expression.Expression;
import fr.n7.stl.block.ast.instruction.declaration.VariableDeclaration;
import fr.n7.stl.block.ast.scope.Declaration;
import fr.n7.stl.block.ast.scope.HierarchicalScope;
import fr.n7.stl.block.ast.type.PartialType;
import fr.n7.stl.block.ast.type.Type;
import fr.n7.stl.tam.ast.Fragment;
import fr.n7.stl.tam.ast.Register;
import fr.n7.stl.tam.ast.TAMFactory;
import fr.n7.stl.util.Pair;

public class AttributeDeclaration implements ClassElement, Declaration {
	protected Access access;
    protected EtatElement etat;
    protected Type type;
    protected Pair<String, PartialType> id;
    protected Expression valeur;
    Register registre;
    int off;
    
    public AttributeDeclaration(Access acc, EtatElement et, Type ty, Pair<String, PartialType> ide, Expression val) {
    	access = acc;
    	etat = et;
    	type = ty;
    	id = ide;
    	valeur = val;
    }
    
    public AttributeDeclaration(Type ty) {
    	type = ty;
    }
    
	@Override
	public String getName() {
		return id.getLeft();
	}
	@Override
	public Type getType() {
		return type;
	}
	
	public Access getAccess() {
		return access;
	}
	
	public EtatElement getEtat() {
		return etat;
	}
	
	@Override
	public boolean collectAndBackwardResolve(HierarchicalScope<Declaration> _scope) {
		if (((HierarchicalScope<Declaration>) _scope).accepts(this)) {
			_scope.register(this);
			if (valeur != null) {
				return valeur.collectAndBackwardResolve(_scope);
			}
			return true;
		} else {
			System.out.println("Déjà défini : " + id.getLeft());
			return false;
		}
	}
	@Override
	public boolean fullResolve(HierarchicalScope<Declaration> _scope) {
		if (valeur == null) {
			return type.resolve(_scope);
		}
		return type.resolve(_scope) && valeur.fullResolve(_scope);
	}
	@Override
	public boolean checkType() {
		if (valeur == null) {
			return true;
		} else {
			if (type.compatibleWith(valeur.getType()) || valeur.getType().compatibleWith(type)) {
				return true;
			} else {
				System.out.println("Type de l'attribut non compatible :" + id.getLeft());
				return false;
			}
		}
	}
	@Override
	public int allocateMemory(Register _register, int _offset) {
		registre = _register;
		off = _offset;
		return type.length();
	}
	@Override
	public Fragment getCode(TAMFactory _factory) {
		Fragment res = _factory.createFragment();
		if (valeur == null) {
			res.add(_factory.createPush(type.length()));
		} else {
			res.append(valeur.getCode(_factory));
			res.add(_factory.createStore(registre, off, type.length()));
		}
		res.addPrefix("debut:" + id.getLeft());
		res.addSuffix("fin:" + id.getLeft());
		return res;
	}
}
