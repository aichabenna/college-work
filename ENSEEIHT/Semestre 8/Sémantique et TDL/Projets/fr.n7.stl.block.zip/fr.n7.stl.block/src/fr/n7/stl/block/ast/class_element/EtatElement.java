package fr.n7.stl.block.ast.class_element;

public enum EtatElement {

    Rien,
    Static,
    Final,
    StaticFinal;

    public String toString() {
        switch (this) {
            case Rien:
                return "";
            case Static:
                return "static ";
            case Final:
                return "final ";
            case StaticFinal:
                return "static final ";
            default:
                throw new IllegalArgumentException("Cas par défaut jamais déclenché");
        }
    }

}
