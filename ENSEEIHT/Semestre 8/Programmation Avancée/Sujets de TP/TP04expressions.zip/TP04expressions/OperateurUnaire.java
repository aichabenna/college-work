/**
  * Opérateur unaire.
  *
  * @author	Xavier Crégut
  * @version	$Revision$
  */
public interface OperateurUnaire {
}
