/**
  * Opérateur binaire d'addition.
  *
  * @author	Xavier Crégut
  * @version	$Revision$
  */
public class Addition implements OperateurBinaire {


}
