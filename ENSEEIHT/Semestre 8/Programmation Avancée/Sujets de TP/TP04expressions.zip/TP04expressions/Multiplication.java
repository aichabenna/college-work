/**
  * Opérateur binaire de multiplication.
  *
  * @author	Xavier Crégut
  * @version	$Revision$
  */
public class Multiplication implements OperateurBinaire {


}
