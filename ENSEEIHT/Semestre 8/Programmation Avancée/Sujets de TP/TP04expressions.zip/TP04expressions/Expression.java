/**
  * Expression entière.
  *
  * @author	Xavier Crégut
  * @version	$Revision$
  */

public interface Expression {

}
