/**
  * Opérateur unaire correspondant à la négation.
  *
  * @author	Xavier Crégut
  * @version	$Revision$
  */

public class Negation implements OperateurUnaire {


}
